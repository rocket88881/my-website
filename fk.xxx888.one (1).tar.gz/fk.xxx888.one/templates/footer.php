    </main>
    <footer class="footer">
        <div class="container">
            <div class="footer-links">
                <a href="#" class="footer-link">关于我们</a>
                <a href="#" class="footer-link">服务条款</a>
                <a href="#" class="footer-link">隐私政策</a>
                <a href="#" class="footer-link">帮助中心</a>
            </div>
            <div class="copyright">
                &copy; <?= date('Y') ?> <?= SITE_NAME ?> 版权所有
            </div>
        </div>
    </footer>
    <script src="/assets/js/main.js"></script>
</body>
</html>