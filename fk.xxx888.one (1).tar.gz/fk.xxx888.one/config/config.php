<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_USER', 'sql_fk_xxx888_on');
define('DB_PASS', '43a73c21b7683');
define('DB_NAME', 'sql_fk_xxx888_on');

// 易支付配置
define('EPAY_PID', '1379');
define('EPAY_KEY', 'ddib7hiJd7vh8IdZIfioFIH8BoGaZIbV');
define('EPAY_API', 'https://pay.lhguomy.xyz/');

// 网站配置
define('SITE_NAME', 'Rocket Cloud 加速器购买');
define('SITE_URL', 'https://fk.xxx888.one');

// 开启错误报告（开发阶段）
error_reporting(E_ALL);
ini_set('display_errors', 1);